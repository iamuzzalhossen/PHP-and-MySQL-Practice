<?php
    // Declare variable with dollar sign ($)
    // $name = "Uzzal";
    // echo $name;

    $name = "Uzzal Hossen";
    $age = "25";

    // echo "My name is ";
    // echo $name;
    // echo " and my age is ";
    // echo $age;

    // Join Variables using the dot (.) concatenation operator
    echo "My name is " .$name ." and my age is " .$age ."<br>";

    $firstName = "Uzzal";
    $lastName = "Hossen";

    echo $fullName = "My full name is " .$firstName ." " .$lastName;

    // Calculate two defined variables
    $a = 20;
    $b = 10;
    $c = $a + $b;

    echo "<br>" .$c;
?>