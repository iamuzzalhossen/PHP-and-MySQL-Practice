<?php
    // Single quote
    echo 'PHP is a programming language';

    // Double quote
    echo "PHP is a programming language";

    // Single quote within double quote
    echo "'PHP means Hypertext Preprocessor'";

    // Escape double quotes using backslashes (\)
    echo "Bangladesh is my \"motherland\"";

    // Escape single quote using backslashes (\)
    echo 'Bangladesh is my \'motherland\'';
?>